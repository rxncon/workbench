from django.apps import AppConfig


class RuleBasedConfig(AppConfig):
    name = 'rule_based'

from django.apps import AppConfig


class QuickFormatConfig(AppConfig):
    name = 'quick_format'

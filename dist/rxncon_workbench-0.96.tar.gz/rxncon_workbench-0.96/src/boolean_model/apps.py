from django.apps import AppConfig


class BooleanModelConfig(AppConfig):
    name = 'boolean_model'

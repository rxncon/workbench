CREATE -- make new -- POST
RETRIEVE -- GET -- List / Search
UPDATE -- Edit -- PUT/PATCH
DELETE -- Delete -- DELETE


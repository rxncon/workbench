from django.apps import AppConfig


class FiletreeConfig(AppConfig):
    name = 'fileTree'

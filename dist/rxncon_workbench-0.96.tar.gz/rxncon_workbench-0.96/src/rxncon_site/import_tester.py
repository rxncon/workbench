class ImportTester():
    # no functionality, used to check if relative import (django dev) or absolute (pipy package) is needed
    pass
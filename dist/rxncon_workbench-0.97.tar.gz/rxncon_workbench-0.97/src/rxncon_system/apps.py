from django.apps import AppConfig


class RxnconSystemConfig(AppConfig):
    name = 'rxncon_system'
